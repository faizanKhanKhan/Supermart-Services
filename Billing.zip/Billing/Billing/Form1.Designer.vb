﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.textBox24 = New System.Windows.Forms.TextBox()
        Me.label28 = New System.Windows.Forms.Label()
        Me.groupBox4 = New System.Windows.Forms.GroupBox()
        Me.textBox18 = New System.Windows.Forms.TextBox()
        Me.textBox19 = New System.Windows.Forms.TextBox()
        Me.textBox20 = New System.Windows.Forms.TextBox()
        Me.textBox21 = New System.Windows.Forms.TextBox()
        Me.label27 = New System.Windows.Forms.Label()
        Me.label25 = New System.Windows.Forms.Label()
        Me.label26 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.textBox26 = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.textBox27 = New System.Windows.Forms.TextBox()
        Me.label24 = New System.Windows.Forms.Label()
        Me.textBox13 = New System.Windows.Forms.TextBox()
        Me.textBox15 = New System.Windows.Forms.TextBox()
        Me.label23 = New System.Windows.Forms.Label()
        Me.textBox16 = New System.Windows.Forms.TextBox()
        Me.textBox17 = New System.Windows.Forms.TextBox()
        Me.label21 = New System.Windows.Forms.Label()
        Me.label12 = New System.Windows.Forms.Label()
        Me.textBox25 = New System.Windows.Forms.TextBox()
        Me.textBox14 = New System.Windows.Forms.TextBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.textBox30 = New System.Windows.Forms.TextBox()
        Me.groupBox7 = New System.Windows.Forms.GroupBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.label31 = New System.Windows.Forms.Label()
        Me.label29 = New System.Windows.Forms.Label()
        Me.label30 = New System.Windows.Forms.Label()
        Me.button1 = New System.Windows.Forms.Button()
        Me.groupBox6 = New System.Windows.Forms.GroupBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.textBox22 = New System.Windows.Forms.TextBox()
        Me.textBox28 = New System.Windows.Forms.TextBox()
        Me.textBox29 = New System.Windows.Forms.TextBox()
        Me.label22 = New System.Windows.Forms.Label()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.label20 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.textBox5 = New System.Windows.Forms.TextBox()
        Me.textBox6 = New System.Windows.Forms.TextBox()
        Me.textBox7 = New System.Windows.Forms.TextBox()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.label19 = New System.Windows.Forms.Label()
        Me.textBox8 = New System.Windows.Forms.TextBox()
        Me.textBox9 = New System.Windows.Forms.TextBox()
        Me.label18 = New System.Windows.Forms.Label()
        Me.textBox10 = New System.Windows.Forms.TextBox()
        Me.textBox11 = New System.Windows.Forms.TextBox()
        Me.label17 = New System.Windows.Forms.Label()
        Me.textBox12 = New System.Windows.Forms.TextBox()
        Me.label15 = New System.Windows.Forms.Label()
        Me.label16 = New System.Windows.Forms.Label()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.groupBox5 = New System.Windows.Forms.GroupBox()
        Me.label14 = New System.Windows.Forms.Label()
        Me.textBox23 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.groupBox4.SuspendLayout()
        Me.groupBox7.SuspendLayout()
        Me.groupBox6.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.groupBox5.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'textBox24
        '
        Me.textBox24.Location = New System.Drawing.Point(283, 99)
        Me.textBox24.Name = "textBox24"
        Me.textBox24.Size = New System.Drawing.Size(179, 30)
        Me.textBox24.TabIndex = 5
        '
        'label28
        '
        Me.label28.AutoSize = True
        Me.label28.Location = New System.Drawing.Point(6, 176)
        Me.label28.Name = "label28"
        Me.label28.Size = New System.Drawing.Size(254, 25)
        Me.label28.TabIndex = 18
        Me.label28.Text = "Total Cost of Cold Drinks"
        '
        'groupBox4
        '
        Me.groupBox4.Controls.Add(Me.label28)
        Me.groupBox4.Controls.Add(Me.textBox18)
        Me.groupBox4.Controls.Add(Me.textBox19)
        Me.groupBox4.Controls.Add(Me.textBox20)
        Me.groupBox4.Controls.Add(Me.textBox21)
        Me.groupBox4.Controls.Add(Me.label27)
        Me.groupBox4.Controls.Add(Me.label25)
        Me.groupBox4.Controls.Add(Me.label26)
        Me.groupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox4.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.groupBox4.Location = New System.Drawing.Point(644, 521)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(478, 215)
        Me.groupBox4.TabIndex = 18
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "Total Product Price"
        '
        'textBox18
        '
        Me.textBox18.Location = New System.Drawing.Point(287, 63)
        Me.textBox18.Name = "textBox18"
        Me.textBox18.Size = New System.Drawing.Size(172, 30)
        Me.textBox18.TabIndex = 4
        '
        'textBox19
        '
        Me.textBox19.Location = New System.Drawing.Point(287, 101)
        Me.textBox19.Name = "textBox19"
        Me.textBox19.Size = New System.Drawing.Size(172, 30)
        Me.textBox19.TabIndex = 5
        '
        'textBox20
        '
        Me.textBox20.Location = New System.Drawing.Point(287, 138)
        Me.textBox20.Name = "textBox20"
        Me.textBox20.Size = New System.Drawing.Size(172, 30)
        Me.textBox20.TabIndex = 6
        '
        'textBox21
        '
        Me.textBox21.Location = New System.Drawing.Point(287, 175)
        Me.textBox21.Name = "textBox21"
        Me.textBox21.Size = New System.Drawing.Size(172, 30)
        Me.textBox21.TabIndex = 7
        '
        'label27
        '
        Me.label27.AutoSize = True
        Me.label27.Location = New System.Drawing.Point(8, 140)
        Me.label27.Name = "label27"
        Me.label27.Size = New System.Drawing.Size(251, 25)
        Me.label27.TabIndex = 18
        Me.label27.Text = "Total Cost of Vegetables"
        '
        'label25
        '
        Me.label25.AutoSize = True
        Me.label25.Location = New System.Drawing.Point(6, 68)
        Me.label25.Name = "label25"
        Me.label25.Size = New System.Drawing.Size(229, 25)
        Me.label25.TabIndex = 18
        Me.label25.Text = "Total Cost of Grocerys"
        '
        'label26
        '
        Me.label26.AutoSize = True
        Me.label26.Location = New System.Drawing.Point(6, 104)
        Me.label26.Name = "label26"
        Me.label26.Size = New System.Drawing.Size(180, 25)
        Me.label26.TabIndex = 18
        Me.label26.Text = "Total Cost of Oils"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(6, 97)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(83, 25)
        Me.label11.TabIndex = 18
        Me.label11.Text = "Mirinda"
        '
        'textBox26
        '
        Me.textBox26.Location = New System.Drawing.Point(283, 171)
        Me.textBox26.Name = "textBox26"
        Me.textBox26.Size = New System.Drawing.Size(179, 30)
        Me.textBox26.TabIndex = 7
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(6, 63)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(57, 25)
        Me.label10.TabIndex = 18
        Me.label10.Text = "Sprit"
        '
        'textBox27
        '
        Me.textBox27.Location = New System.Drawing.Point(283, 207)
        Me.textBox27.Name = "textBox27"
        Me.textBox27.Size = New System.Drawing.Size(179, 30)
        Me.textBox27.TabIndex = 8
        '
        'label24
        '
        Me.label24.AutoSize = True
        Me.label24.Location = New System.Drawing.Point(6, 193)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(70, 25)
        Me.label24.TabIndex = 18
        Me.label24.Text = "Onion"
        '
        'textBox13
        '
        Me.textBox13.Location = New System.Drawing.Point(245, 53)
        Me.textBox13.Name = "textBox13"
        Me.textBox13.Size = New System.Drawing.Size(181, 30)
        Me.textBox13.TabIndex = 4
        '
        'textBox15
        '
        Me.textBox15.Location = New System.Drawing.Point(245, 125)
        Me.textBox15.Name = "textBox15"
        Me.textBox15.Size = New System.Drawing.Size(181, 30)
        Me.textBox15.TabIndex = 6
        '
        'label23
        '
        Me.label23.AutoSize = True
        Me.label23.Location = New System.Drawing.Point(6, 157)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(120, 25)
        Me.label23.TabIndex = 18
        Me.label23.Text = "LadyFinger"
        '
        'textBox16
        '
        Me.textBox16.Location = New System.Drawing.Point(245, 161)
        Me.textBox16.Name = "textBox16"
        Me.textBox16.Size = New System.Drawing.Size(181, 30)
        Me.textBox16.TabIndex = 7
        '
        'textBox17
        '
        Me.textBox17.Location = New System.Drawing.Point(245, 197)
        Me.textBox17.Name = "textBox17"
        Me.textBox17.Size = New System.Drawing.Size(181, 30)
        Me.textBox17.TabIndex = 8
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Location = New System.Drawing.Point(6, 51)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(74, 25)
        Me.label21.TabIndex = 18
        Me.label21.Text = "Potato"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(6, 133)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(108, 25)
        Me.label12.TabIndex = 18
        Me.label12.Text = "CocaCola"
        '
        'textBox25
        '
        Me.textBox25.Location = New System.Drawing.Point(283, 135)
        Me.textBox25.Name = "textBox25"
        Me.textBox25.Size = New System.Drawing.Size(179, 30)
        Me.textBox25.TabIndex = 6
        '
        'textBox14
        '
        Me.textBox14.Location = New System.Drawing.Point(245, 89)
        Me.textBox14.Name = "textBox14"
        Me.textBox14.Size = New System.Drawing.Size(181, 30)
        Me.textBox14.TabIndex = 5
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(6, 169)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(60, 25)
        Me.label13.TabIndex = 18
        Me.label13.Text = "Slice"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label4.Location = New System.Drawing.Point(636, 29)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(567, 46)
        Me.label4.TabIndex = 29
        Me.label4.Text = "CUSTOMER BILLING  PAGE"
        '
        'textBox30
        '
        Me.textBox30.Location = New System.Drawing.Point(1245, 47)
        Me.textBox30.Multiline = True
        Me.textBox30.Name = "textBox30"
        Me.textBox30.Size = New System.Drawing.Size(252, 33)
        Me.textBox30.TabIndex = 5
        '
        'groupBox7
        '
        Me.groupBox7.Controls.Add(Me.textBox30)
        Me.groupBox7.Controls.Add(Me.label3)
        Me.groupBox7.Controls.Add(Me.textBox1)
        Me.groupBox7.Controls.Add(Me.label2)
        Me.groupBox7.Controls.Add(Me.textBox2)
        Me.groupBox7.Controls.Add(Me.label1)
        Me.groupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.groupBox7.Location = New System.Drawing.Point(96, 78)
        Me.groupBox7.Name = "groupBox7"
        Me.groupBox7.Size = New System.Drawing.Size(1515, 100)
        Me.groupBox7.TabIndex = 28
        Me.groupBox7.TabStop = False
        Me.groupBox7.Text = "Customer Details"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(1058, 47)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(149, 29)
        Me.label3.TabIndex = 4
        Me.label3.Text = "Contact No."
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(202, 47)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(254, 33)
        Me.textBox1.TabIndex = 1
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(531, 47)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(82, 29)
        Me.label2.TabIndex = 2
        Me.label2.Text = "Name"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(648, 47)
        Me.textBox2.Multiline = True
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(358, 33)
        Me.textBox2.TabIndex = 3
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(26, 47)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(101, 29)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Cust Id."
        '
        'listBox1
        '
        Me.listBox1.BackColor = System.Drawing.Color.BurlyWood
        Me.listBox1.FormattingEnabled = True
        Me.listBox1.ItemHeight = 16
        Me.listBox1.Location = New System.Drawing.Point(1641, 80)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(209, 692)
        Me.listBox1.TabIndex = 27
        '
        'button3
        '
        Me.button3.BackColor = System.Drawing.Color.Red
        Me.button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.button3.Location = New System.Drawing.Point(1013, 807)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(204, 60)
        Me.button3.TabIndex = 26
        Me.button3.Text = "EXIT"
        Me.button3.UseVisualStyleBackColor = False
        '
        'button2
        '
        Me.button2.BackColor = System.Drawing.Color.Yellow
        Me.button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button2.Location = New System.Drawing.Point(655, 807)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(204, 60)
        Me.button2.TabIndex = 25
        Me.button2.Text = "RESET"
        Me.button2.UseVisualStyleBackColor = False
        '
        'label31
        '
        Me.label31.AutoSize = True
        Me.label31.Location = New System.Drawing.Point(27, 169)
        Me.label31.Name = "label31"
        Me.label31.Size = New System.Drawing.Size(141, 25)
        Me.label31.TabIndex = 18
        Me.label31.Text = "Total Amount"
        '
        'label29
        '
        Me.label29.AutoSize = True
        Me.label29.Location = New System.Drawing.Point(27, 63)
        Me.label29.Name = "label29"
        Me.label29.Size = New System.Drawing.Size(106, 25)
        Me.label29.TabIndex = 18
        Me.label29.Text = "Sub Total"
        '
        'label30
        '
        Me.label30.AutoSize = True
        Me.label30.Location = New System.Drawing.Point(27, 112)
        Me.label30.Name = "label30"
        Me.label30.Size = New System.Drawing.Size(57, 25)
        Me.label30.TabIndex = 18
        Me.label30.Text = "GST"
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.Color.Lime
        Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.button1.Location = New System.Drawing.Point(310, 807)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(205, 60)
        Me.button1.TabIndex = 24
        Me.button1.Text = "SUBMIT"
        Me.button1.UseVisualStyleBackColor = False
        '
        'groupBox6
        '
        Me.groupBox6.Controls.Add(Me.TextBox33)
        Me.groupBox6.Controls.Add(Me.TextBox32)
        Me.groupBox6.Controls.Add(Me.TextBox31)
        Me.groupBox6.Controls.Add(Me.label31)
        Me.groupBox6.Controls.Add(Me.textBox22)
        Me.groupBox6.Controls.Add(Me.textBox28)
        Me.groupBox6.Controls.Add(Me.textBox29)
        Me.groupBox6.Controls.Add(Me.label29)
        Me.groupBox6.Controls.Add(Me.label30)
        Me.groupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.groupBox6.Location = New System.Drawing.Point(1171, 521)
        Me.groupBox6.Name = "groupBox6"
        Me.groupBox6.Size = New System.Drawing.Size(440, 215)
        Me.groupBox6.TabIndex = 19
        Me.groupBox6.TabStop = False
        Me.groupBox6.Text = "Total Price"
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(238, 169)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(184, 30)
        Me.TextBox33.TabIndex = 19
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(238, 117)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(184, 30)
        Me.TextBox32.TabIndex = 19
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(238, 68)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(184, 30)
        Me.TextBox31.TabIndex = 19
        '
        'textBox22
        '
        Me.textBox22.Location = New System.Drawing.Point(475, 93)
        Me.textBox22.Multiline = True
        Me.textBox22.Name = "textBox22"
        Me.textBox22.Size = New System.Drawing.Size(160, 30)
        Me.textBox22.TabIndex = 4
        '
        'textBox28
        '
        Me.textBox28.Location = New System.Drawing.Point(475, 144)
        Me.textBox28.Multiline = True
        Me.textBox28.Name = "textBox28"
        Me.textBox28.Size = New System.Drawing.Size(160, 30)
        Me.textBox28.TabIndex = 5
        '
        'textBox29
        '
        Me.textBox29.Location = New System.Drawing.Point(475, 196)
        Me.textBox29.Multiline = True
        Me.textBox29.Name = "textBox29"
        Me.textBox29.Size = New System.Drawing.Size(160, 30)
        Me.textBox29.TabIndex = 6
        '
        'label22
        '
        Me.label22.AutoSize = True
        Me.label22.Location = New System.Drawing.Point(6, 121)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(107, 25)
        Me.label22.TabIndex = 18
        Me.label22.Text = "Coliflower"
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.label24)
        Me.groupBox3.Controls.Add(Me.textBox13)
        Me.groupBox3.Controls.Add(Me.textBox14)
        Me.groupBox3.Controls.Add(Me.textBox15)
        Me.groupBox3.Controls.Add(Me.label23)
        Me.groupBox3.Controls.Add(Me.textBox16)
        Me.groupBox3.Controls.Add(Me.textBox17)
        Me.groupBox3.Controls.Add(Me.label21)
        Me.groupBox3.Controls.Add(Me.label22)
        Me.groupBox3.Controls.Add(Me.label20)
        Me.groupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox3.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.groupBox3.Location = New System.Drawing.Point(1167, 246)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(444, 236)
        Me.groupBox3.TabIndex = 20
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Vegetables Per Kg."
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.Location = New System.Drawing.Point(6, 85)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(85, 25)
        Me.label20.TabIndex = 18
        Me.label20.Text = "Tomato"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(6, 195)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(80, 25)
        Me.label9.TabIndex = 18
        Me.label9.Text = "Peanut"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(6, 159)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(64, 25)
        Me.label8.TabIndex = 18
        Me.label8.Text = "Grain"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(6, 123)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(75, 25)
        Me.label7.TabIndex = 18
        Me.label7.Text = "Wheat"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(6, 87)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(44, 25)
        Me.label6.TabIndex = 18
        Me.label6.Text = "Dal"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(6, 53)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(54, 25)
        Me.label5.TabIndex = 18
        Me.label5.Text = "Rice"
        '
        'textBox3
        '
        Me.textBox3.Location = New System.Drawing.Point(283, 51)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(179, 30)
        Me.textBox3.TabIndex = 5
        '
        'textBox4
        '
        Me.textBox4.Location = New System.Drawing.Point(283, 87)
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(179, 30)
        Me.textBox4.TabIndex = 5
        '
        'textBox5
        '
        Me.textBox5.Location = New System.Drawing.Point(283, 123)
        Me.textBox5.Name = "textBox5"
        Me.textBox5.Size = New System.Drawing.Size(179, 30)
        Me.textBox5.TabIndex = 6
        '
        'textBox6
        '
        Me.textBox6.Location = New System.Drawing.Point(283, 159)
        Me.textBox6.Name = "textBox6"
        Me.textBox6.Size = New System.Drawing.Size(179, 30)
        Me.textBox6.TabIndex = 7
        '
        'textBox7
        '
        Me.textBox7.Location = New System.Drawing.Point(283, 195)
        Me.textBox7.Name = "textBox7"
        Me.textBox7.Size = New System.Drawing.Size(179, 30)
        Me.textBox7.TabIndex = 8
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.label19)
        Me.groupBox2.Controls.Add(Me.textBox8)
        Me.groupBox2.Controls.Add(Me.textBox9)
        Me.groupBox2.Controls.Add(Me.label18)
        Me.groupBox2.Controls.Add(Me.textBox10)
        Me.groupBox2.Controls.Add(Me.textBox11)
        Me.groupBox2.Controls.Add(Me.label17)
        Me.groupBox2.Controls.Add(Me.textBox12)
        Me.groupBox2.Controls.Add(Me.label15)
        Me.groupBox2.Controls.Add(Me.label16)
        Me.groupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.groupBox2.Location = New System.Drawing.Point(644, 246)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(478, 236)
        Me.groupBox2.TabIndex = 21
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Oil Per Ltr."
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.Location = New System.Drawing.Point(6, 193)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(122, 25)
        Me.label19.TabIndex = 18
        Me.label19.Text = "Pomolin Oil"
        '
        'textBox8
        '
        Me.textBox8.Location = New System.Drawing.Point(281, 53)
        Me.textBox8.Name = "textBox8"
        Me.textBox8.Size = New System.Drawing.Size(180, 30)
        Me.textBox8.TabIndex = 4
        '
        'textBox9
        '
        Me.textBox9.Location = New System.Drawing.Point(281, 89)
        Me.textBox9.Name = "textBox9"
        Me.textBox9.Size = New System.Drawing.Size(180, 30)
        Me.textBox9.TabIndex = 5
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Location = New System.Drawing.Point(6, 157)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(141, 25)
        Me.label18.TabIndex = 18
        Me.label18.Text = "Sunflower Oil"
        '
        'textBox10
        '
        Me.textBox10.Location = New System.Drawing.Point(281, 125)
        Me.textBox10.Name = "textBox10"
        Me.textBox10.Size = New System.Drawing.Size(180, 30)
        Me.textBox10.TabIndex = 6
        '
        'textBox11
        '
        Me.textBox11.Location = New System.Drawing.Point(281, 161)
        Me.textBox11.Name = "textBox11"
        Me.textBox11.Size = New System.Drawing.Size(180, 30)
        Me.textBox11.TabIndex = 7
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Location = New System.Drawing.Point(6, 121)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(113, 25)
        Me.label17.TabIndex = 18
        Me.label17.Text = "Peanut Oil"
        '
        'textBox12
        '
        Me.textBox12.Location = New System.Drawing.Point(281, 197)
        Me.textBox12.Name = "textBox12"
        Me.textBox12.Size = New System.Drawing.Size(180, 30)
        Me.textBox12.TabIndex = 8
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Location = New System.Drawing.Point(6, 51)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(123, 25)
        Me.label15.TabIndex = 18
        Me.label15.Text = "Mustard Oil"
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Location = New System.Drawing.Point(6, 85)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(126, 25)
        Me.label16.TabIndex = 18
        Me.label16.Text = "Coconut Oil"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.label9)
        Me.groupBox1.Controls.Add(Me.label8)
        Me.groupBox1.Controls.Add(Me.label7)
        Me.groupBox1.Controls.Add(Me.label6)
        Me.groupBox1.Controls.Add(Me.label5)
        Me.groupBox1.Controls.Add(Me.textBox3)
        Me.groupBox1.Controls.Add(Me.textBox4)
        Me.groupBox1.Controls.Add(Me.textBox5)
        Me.groupBox1.Controls.Add(Me.textBox6)
        Me.groupBox1.Controls.Add(Me.textBox7)
        Me.groupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.groupBox1.Location = New System.Drawing.Point(91, 246)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(484, 236)
        Me.groupBox1.TabIndex = 22
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Grocery Per Kg."
        '
        'groupBox5
        '
        Me.groupBox5.Controls.Add(Me.label14)
        Me.groupBox5.Controls.Add(Me.textBox23)
        Me.groupBox5.Controls.Add(Me.label13)
        Me.groupBox5.Controls.Add(Me.textBox24)
        Me.groupBox5.Controls.Add(Me.label12)
        Me.groupBox5.Controls.Add(Me.textBox25)
        Me.groupBox5.Controls.Add(Me.label11)
        Me.groupBox5.Controls.Add(Me.textBox26)
        Me.groupBox5.Controls.Add(Me.label10)
        Me.groupBox5.Controls.Add(Me.textBox27)
        Me.groupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox5.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.groupBox5.Location = New System.Drawing.Point(96, 521)
        Me.groupBox5.Name = "groupBox5"
        Me.groupBox5.Size = New System.Drawing.Size(484, 251)
        Me.groupBox5.TabIndex = 23
        Me.groupBox5.TabStop = False
        Me.groupBox5.Text = "Cold Drinks Per Ltr."
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Location = New System.Drawing.Point(6, 210)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(66, 25)
        Me.label14.TabIndex = 18
        Me.label14.Text = "Pepsi"
        '
        'textBox23
        '
        Me.textBox23.Location = New System.Drawing.Point(283, 63)
        Me.textBox23.Name = "textBox23"
        Me.textBox23.Size = New System.Drawing.Size(179, 30)
        Me.textBox23.TabIndex = 4
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.OrangeRed
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(1347, 807)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(204, 59)
        Me.Button4.TabIndex = 30
        Me.Button4.Text = "NEXT"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(107, 883)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1509, 95)
        Me.DataGridView1.TabIndex = 31
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(1870, 994)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.groupBox4)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.groupBox7)
        Me.Controls.Add(Me.listBox1)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.groupBox6)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.groupBox5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox4.ResumeLayout(False)
        Me.groupBox4.PerformLayout()
        Me.groupBox7.ResumeLayout(False)
        Me.groupBox7.PerformLayout()
        Me.groupBox6.ResumeLayout(False)
        Me.groupBox6.PerformLayout()
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox3.PerformLayout()
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox2.PerformLayout()
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        Me.groupBox5.ResumeLayout(False)
        Me.groupBox5.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents textBox24 As TextBox
    Private WithEvents label28 As Label
    Private WithEvents groupBox4 As GroupBox
    Private WithEvents textBox18 As TextBox
    Private WithEvents textBox19 As TextBox
    Private WithEvents textBox20 As TextBox
    Private WithEvents textBox21 As TextBox
    Private WithEvents label27 As Label
    Private WithEvents label25 As Label
    Private WithEvents label26 As Label
    Private WithEvents label11 As Label
    Private WithEvents textBox26 As TextBox
    Private WithEvents label10 As Label
    Private WithEvents textBox27 As TextBox
    Private WithEvents label24 As Label
    Private WithEvents textBox13 As TextBox
    Private WithEvents textBox15 As TextBox
    Private WithEvents label23 As Label
    Private WithEvents textBox16 As TextBox
    Private WithEvents textBox17 As TextBox
    Private WithEvents label21 As Label
    Private WithEvents label12 As Label
    Private WithEvents textBox25 As TextBox
    Private WithEvents textBox14 As TextBox
    Private WithEvents label13 As Label
    Private WithEvents label4 As Label
    Private WithEvents textBox30 As TextBox
    Private WithEvents groupBox7 As GroupBox
    Private WithEvents label3 As Label
    Private WithEvents textBox1 As TextBox
    Private WithEvents label2 As Label
    Private WithEvents textBox2 As TextBox
    Private WithEvents label1 As Label
    Private WithEvents listBox1 As ListBox
    Private WithEvents button3 As Button
    Private WithEvents button2 As Button
    Private WithEvents label31 As Label
    Private WithEvents label29 As Label
    Private WithEvents label30 As Label
    Private WithEvents button1 As Button
    Private WithEvents groupBox6 As GroupBox
    Private WithEvents label22 As Label
    Private WithEvents groupBox3 As GroupBox
    Private WithEvents label20 As Label
    Private WithEvents label9 As Label
    Private WithEvents label8 As Label
    Private WithEvents label7 As Label
    Private WithEvents label6 As Label
    Private WithEvents label5 As Label
    Private WithEvents textBox3 As TextBox
    Private WithEvents textBox4 As TextBox
    Private WithEvents textBox5 As TextBox
    Private WithEvents textBox6 As TextBox
    Private WithEvents textBox7 As TextBox
    Private WithEvents groupBox2 As GroupBox
    Private WithEvents label19 As Label
    Private WithEvents textBox8 As TextBox
    Private WithEvents textBox9 As TextBox
    Private WithEvents label18 As Label
    Private WithEvents textBox10 As TextBox
    Private WithEvents textBox11 As TextBox
    Private WithEvents label17 As Label
    Private WithEvents textBox12 As TextBox
    Private WithEvents label15 As Label
    Private WithEvents label16 As Label
    Private WithEvents groupBox1 As GroupBox
    Private WithEvents groupBox5 As GroupBox
    Private WithEvents label14 As Label
    Private WithEvents textBox23 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents TextBox33 As TextBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TextBox32 As TextBox
    Private WithEvents textBox22 As TextBox
    Private WithEvents textBox28 As TextBox
    Private WithEvents textBox29 As TextBox
End Class
